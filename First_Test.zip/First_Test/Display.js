class RGB {
  constructor(inputtedR, inputtedG, inputtedB) {
    this.r = inputtedR; // Red component
    this.g = inputtedG; // Green component
    this.b = inputtedB; // Blue component
  }

  // Getter for the red component
  getR() {
    return this.r;
  }

  // Getter for the green component
  getG() {
    return this.g;
  }

  // Getter for the blue component
  getB() {
    return this.b;
  }

  // Method to change the RGB values
  change(inputtedR, inputtedG, inputtedB) {
    this.r = inputtedR;
    this.g = inputtedG;
    this.b = inputtedB;
  }
}